# Goldy Porter - Brick Breaker (Mobile Ready)

A classic brick breaker game made with HTML, CSS, and JavaScript. Now mobile-friendly!

## How to Play
- **Desktop:** Arrow Left/Right to move the paddle.
- **Mobile:** Drag your finger left/right to move the paddle.
- Break all the golden bricks and score points.
- You have 3 lives. Game ends when all lives are lost.

## Live Preview
Open `index.html` in your browser or on your mobile device.

## License
MIT License
